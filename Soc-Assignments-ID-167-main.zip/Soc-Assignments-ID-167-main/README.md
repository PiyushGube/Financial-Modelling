All assignment code files are inside their respective named folders.
I have done Assignment 1 and 3 in Jupyter Notebook. Others are simple python codes.
